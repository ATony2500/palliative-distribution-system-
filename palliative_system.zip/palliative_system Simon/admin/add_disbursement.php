<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $user_id = (int)$_POST['user_id'];
    $details = sanitizeInput($_POST['details']);
    $stmt = $conn->prepare("INSERT INTO disbursements (user_id, disbursement_details) VALUES (?, ?)");
    $stmt->bind_param('is', $user_id, $details);
    if ($stmt->execute()) {
        logAudit("Disbursement added for user ID: $user_id", $_SESSION['user_id']);
        $alertMessage = 'Disbursement logged successfully!';
        $alertActionUrl = 'disbursement_history.php';
        $alertActionText = 'View History';
    } else {
        $alertMessage = 'Error logging disbursement.';
    }
    $stmt->close();
}

$stmt = $conn->prepare("SELECT id, name FROM users WHERE id IN (SELECT user_id FROM user_biodata WHERE eligibility_status = 'approved')");
$stmt->execute();
$users = $stmt->get_result();
?>
<!--  -->
  <!--  -->
<?php
require_once '../includes/functions.php';
?>
<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="en-us">

<head>
    <meta charset="utf-8">
    <title>Wallet - Payday Loan Service Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta name="description" content="This is meta description">
    <meta name="author" content="Themefisher">
    <link rel="shortcut icon" href="../theme/images/favicon.png" type="image/x-icon">
    <link rel="icon" href="../theme/images/favicon.png" type="image/x-icon">

    <!-- theme meta -->
    <meta name="theme-name" content="wallet" />

    <!-- # Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- # CSS Plugins -->
    <link rel="stylesheet" href="../theme/plugins/slick/slick.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/fontawesome.min.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/brands.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/solid.css">

    <!-- # Main Style Sheet -->
    <link rel="stylesheet" href="../theme/css/style.css">
    <script>
        function showAlertModal(message, actionUrl = '', actionText = 'Close') {
            let modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Alert</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">${message}</div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="if('${actionUrl}') window.location.href='${actionUrl}'">${actionText}</button>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(modal);
            let bsModal = new bootstrap.Modal(modal);
            bsModal.show();
            modal.addEventListener('hidden.bs.modal', () => modal.remove());
        }
    </script>
</head>

<body>
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">Palliative System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                    <?php //if (isset($_SESSION['user_id'])): 
                    ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                        <?php //if ($_SESSION['role'] == 'admin'): 
                        ?>
                            <li class="nav-item"><a class="nav-link" href="admin/index.php">Admin Panel</a></li>
                        <?php // endif; 
                        ?>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php //else: 
                    ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <?php //endif; 
                    ?>
                </ul>
            </div>
        </div>
    </nav> -->

    <header class="navigation bg-tertiary">
        <nav class="navbar navbar-expand-xl navbar-light text-center py-3">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img loading="prelaod" decoding="async" class="img-fluid" width="160" src="../theme/images/22222222.png" alt="Wallet">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
                </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">


                        <li class="nav-item"> <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item "> <a class="nav-link" href="add_disbursement.php">Add Disbursement</a>
                        </li>
                        <li class="nav-item "> <a class="nav-link" href="beneficiaries.php">Beneficiaries</a>
                        </li>
                        <li class="nav-item "> <a class="nav-link" href="disbursement_history.php">Disbursement history</a>
                        </li>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <li class="nav-item"> <a class="nav-link" href="create_admin.php">Create Admin</a></li>
                            <?php if ($_SESSION['role'] == 'admin'): ?>
                                <!-- <li class="nav-item"> <a class="nav-link" href="admin/index.php">Admin Panel</a></li> -->
                            <?php endif; ?>
                            <a href="deliveries.php" class="btn btn-info mb-2">Manage Deliveries</a>

                            <a href="logout.php" class="btn btn-outline-primary">Log Out</a>
                            <!-- <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>  -->
                            <!-- <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li> -->


                    </ul>
                <?php else: ?>
                    <!-- account btn --> <a href="login.php" class="btn btn-outline-primary">Log In</a>
                    <!-- account btn --> <a href="register.php" class="btn btn-primary ms-2 ms-lg-3">Sign Up</a>
                <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>
    <!-- /navigation -->

    <div class="container mt-4">
        <div class="modal fade" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="alertModalLabel">Notification</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="alertModalBody" role="alert"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="alertModalClose">Close</button>
                        <a href="#" class="btn btn-primary d-none" id="alertModalAction" role="button">Proceed</a>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="csrf_token" value="<?php echo generateCsrfToken(); ?>">


<!--  -->
  <!--  --><h2>Add Disbursement</h2>
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
    <div class="mb-3">
        <label for="user_id" class="form-label">Beneficiary</label>
        <select class="form-control" id="user_id" name="user_id" required>
            <?php while ($user = $users->fetch_assoc()): ?>
                <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['name']); ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="details" class="form-label">Disbursement Details</label>
        <textarea class="form-control" id="details" name="details" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Log Disbursement</button>
</form>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
        });
    </script>
<?php endif; ?>
<?php
require_once '../includes/functions.php';
?>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>    <script>
        // Check if bootstrap is defined before using it
        if (typeof bootstrap === 'undefined') {
            console.error('Bootstrap JavaScript is not loaded. Please check if assets/js/bootstrap.bundle.min.js is accessible.');
        }

        function showAlertModal(message, actionUrl = null, actionText = 'Close') {
            if (typeof bootstrap === 'undefined') {
                console.error('Cannot show modal: Bootstrap is not defined.');
                alert(message); // Fallback to native alert
                if (actionUrl) {
                    window.location.href = actionUrl;
                }
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('alertModal'), { backdrop: 'static' });
            const modalBody = document.getElementById('alertModalBody');
            const closeBtn = document.getElementById('alertModalClose');
            const actionBtn = document.getElementById('alertModalAction');

            modalBody.innerText = message;
            if (actionUrl) {
                actionBtn.classList.remove('d-none');
                actionBtn.innerText = actionText;
                actionBtn.onclick = function() {
                    window.location.href = actionUrl;
                };
            } else {
                actionBtn.classList.add('d-none');
            }

            closeBtn.onclick = function() {
                modal.hide();
            };

            modal.show();
            console.log('Modal shown with message:', message, 'Action URL:', actionUrl);
        }
    </script>
</body>
</html><?php $stmt->close(); ?>
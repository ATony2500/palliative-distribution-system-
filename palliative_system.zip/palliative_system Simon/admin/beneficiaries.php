<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: ../login.php');
    exit;
}

$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

// Handle approve/delete
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && isset($_GET['id']) && isset($_GET['csrf_token'])) {
    if (!validateCsrfToken($_GET['csrf_token'])) {
        $alertMessage = 'Invalid CSRF token. Please try again.';
        logError("CSRF token validation failed for action: {$_GET['action']}, ID: {$_GET['id']}");
    } else {
        $id = (int)$_GET['id'];
        try {
            if ($_GET['action'] == 'approve') {
                $stmt = $conn->prepare("UPDATE user_biodata SET eligibility_status = 'approved' WHERE id = ?");
                $stmt->bind_param('i', $id);
                if ($stmt->execute()) {
                    $stmt->close();
                    $stmt = $conn->prepare("SELECT u.id, u.email, b.address, b.unique_id FROM user_biodata b JOIN users u ON b.user_id = u.id WHERE b.id = ?");
                    $stmt->bind_param('i', $id);
                    $stmt->execute();
                    $stmt->bind_result($user_id, $email, $address, $unique_id);
                    $stmt->fetch();
                    $stmt->close();

                    if (createDeliveryRequest($conn, $user_id, $id, $address)) {
                        if (!sendEmail($email, "Eligibility Approved", "Your bio-data ($unique_id) has been approved. A palliative delivery will be scheduled to your address: $address.")) {
                            $alertMessage = 'Beneficiary approved and delivery request created.';
                            logError("Email notification failed for user ID: $user_id");
                        } else {
                            $alertMessage = 'Beneficiary approved and delivery request created!';
                        }
                    } else {
                        $alertMessage = 'Beneficiary approved, but failed to create delivery request.';
                        logError("Failed to create delivery request for user ID: $user_id, biodata ID: $id");
                    }
                    logAudit("Beneficiary approved: ID $id", $_SESSION['user_id']);
                    session_regenerate_id(true);
                } else {
                    $alertMessage = 'Error approving beneficiary.';
                    logError("Failed to approve beneficiary ID $id: " . $conn->error);
                }
            } elseif ($_GET['action'] == 'delete') {
                $stmt = $conn->prepare("DELETE FROM user_biodata WHERE id = ?");
                $stmt->bind_param('i', $id);
                if ($stmt->execute()) {
                    $alertMessage = 'Beneficiary deleted successfully!';
                    logAudit("Beneficiary deleted: ID $id", $_SESSION['user_id']);
                    session_regenerate_id(true);
                } else {
                    $alertMessage = 'Error deleting beneficiary.';
                    logError("Failed to delete beneficiary ID $id: " . $conn->error);
                }
                $stmt->close();
            }
        } catch (Exception $e) {
            $alertMessage = 'An unexpected error occurred.';
            logError("Exception in action {$_GET['action']} for ID $id: " . $e->getMessage());
        }
    }
}

// Pagination
$perPage = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $perPage;

try {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM user_biodata");
    $stmt->execute();
    $stmt->bind_result($total);
    $stmt->fetch();
    $stmt->close();
    $totalPages = $total > 0 ? ceil($total / $perPage) : 1;

    $stmt = $conn->prepare("SELECT b.id, u.name, u.email, b.address, b.dob, b.state_of_origin, b.local_government, b.religion, b.unique_id, b.eligibility_status 
                            FROM users u 
                            JOIN user_biodata b ON u.id = b.user_id 
                            LIMIT ? OFFSET ?");
    $stmt->bind_param('ii', $perPage, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
} catch (Exception $e) {
    $alertMessage = 'Error loading beneficiaries.';
    logError("Failed to load beneficiaries: " . $e->getMessage());
    $result = null;
    $totalPages = 1;
}
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
    <meta charset="utf-8">
    <title>Wallet - Payday Loan Service Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
    <meta name="description" content="This is meta description">
    <meta name="author" content="Themefisher">
    <link rel="shortcut icon" href="../theme/images/favicon.png" type="image/x-icon">
    <link rel="icon" href="../theme/images/favicon.png" type="image/x-icon">
    <meta name="theme-name" content="wallet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../theme/plugins/slick/slick.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/fontawesome.min.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/brands.css">
    <link rel="stylesheet" href="../theme/plugins/font-awesome/solid.css">
    <link rel="stylesheet" href="../theme/css/style.css">
</head>
<body>
    <header class="navigation bg-tertiary">
        <nav class="navbar navbar-expand-xl navbar-light text-center py-3">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img loading="preload" decoding="async" class="img-fluid" width="160" src="../theme/images/22222222.png" alt="Wallet">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="add_disbursement.php">Add Disbursement</a></li>
                        <li class="nav-item"><a class="nav-link" href="beneficiaries.php">Beneficiaries</a></li>
                        <li class="nav-item"><a class="nav-link" href="disbursement_history.php">Disbursement history</a></li>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <li class="nav-item"><a class="nav-link" href="create_admin.php">Create Admin</a></li>
                            <a href="deliveries.php" class="btn btn-info mb-2">Manage Deliveries</a>
                            <a href="logout.php" class="btn btn-outline-primary">Log Out</a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-outline-primary">Log In</a>
                            <a href="register.php" class="btn btn-primary ms-2 ms-lg-3">Sign Up</a>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div class="container mt-4">
        <div class="modal fade" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="alertModalLabel">Confirmation</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="alertModalBody" role="alert"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="alertModalClose" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary d-none" id="alertModalAction">Confirm</button>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" id="csrf_token" value="<?php echo generateCsrfToken(); ?>">
        <h2>Manage Beneficiaries</h2>
        <table class="table table-bordered text-black">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>DOB</th>
                    <th>State of Origin</th>
                    <th>Local Government</th>
                    <th>Religion</th>
                    <th>Unique ID</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['address']); ?></td>
                            <td><?php echo htmlspecialchars($row['dob']); ?></td>
                            <td><?php echo htmlspecialchars($row['state_of_origin']); ?></td>
                            <td><?php echo htmlspecialchars($row['local_government']); ?></td>
                            <td><?php echo htmlspecialchars($row['religion']); ?></td>
                            <td><?php echo htmlspecialchars($row['unique_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['eligibility_status']); ?></td>
                            <td>
                                <?php if ($row['eligibility_status'] != 'approved'): ?>
                                    <button class="btn btn-success btn-sm approve-btn" data-action="approve" data-id="<?php echo $row['id']; ?>" data-csrf="<?php echo generateCsrfToken(); ?>">Approve</button>
                                <?php endif; ?>
                                <button class="btn btn-danger btn-sm delete-btn" data-action="delete" data-id="<?php echo $row['id']; ?>" data-csrf="<?php echo generateCsrfToken(); ?>">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="10" class="text-center">No beneficiaries found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <nav>
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.approve-btn, .delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const action = this.getAttribute('data-action');
                    const id = this.getAttribute('data-id');
                    const csrf = this.getAttribute('data-csrf');
                    const message = action === 'approve' ? 'Approve beneficiary and schedule delivery?' : 'Delete beneficiary?';
                    const url = `beneficiaries.php?action=${action}&id=${id}&csrf_token=${encodeURIComponent(csrf)}`;

                    if (typeof bootstrap === 'undefined') {
                        console.error('Bootstrap not loaded, using native confirm.');
                        if (confirm(message)) {
                            window.location.href = url;
                        }
                    } else {
                        showAlertModal(message, url, 'Confirm');
                    }
                    console.log(`Button clicked: Action=${action}, ID=${id}, CSRF=${csrf}, URL=${url}`);
                });
            });
        });
        </script>
        <?php if ($alertMessage): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
                });
            </script>
        <?php endif; ?>
        <?php
require_once '../includes/functions.php';
?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
    // Check if bootstrap is defined before using it
        if (typeof bootstrap === 'undefined') {
            console.error('Bootstrap JavaScript is not loaded. Please check if assets/js/bootstrap.bundle.min.js is accessible.');
        }

        function showAlertModal(message, actionUrl = null, actionText = 'Close') {
            if (typeof bootstrap === 'undefined') {
                console.error('Cannot show modal: Bootstrap is not defined.');
                alert(message); // Fallback to native alert
                if (actionUrl) {
                    window.location.href = actionUrl;
                }
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('alertModal'), { backdrop: 'static' });
            const modalBody = document.getElementById('alertModalBody');
            const closeBtn = document.getElementById('alertModalClose');
            const actionBtn = document.getElementById('alertModalAction');

            modalBody.innerText = message;
            if (actionUrl) {
                actionBtn.classList.remove('d-none');
                actionBtn.innerText = actionText;
                actionBtn.onclick = function() {
                    window.location.href = actionUrl;
                };
            } else {
                actionBtn.classList.add('d-none');
            }

            closeBtn.onclick = function() {
                modal.hide();
            };

            modal.show();
            console.log('Modal shown with message:', message, 'Action URL:', actionUrl);
        }
    </script>
</body>
</html>
<?php if (isset($stmt)) $stmt->close(); ?>
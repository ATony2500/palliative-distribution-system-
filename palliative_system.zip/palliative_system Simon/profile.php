<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

$stmt = $conn->prepare("SELECT name, email, telephone FROM users WHERE id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($name, $email, $telephone);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("SELECT address, dob, state_of_origin, local_government, religion, passport_photo, unique_id, eligibility_status FROM user_biodata WHERE user_id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$biodata = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $name = sanitizeInput($_POST['name']);
    $telephone = sanitizeInput($_POST['telephone']);
    if (!validatePhone($telephone)) {
        $alertMessage = 'Invalid phone number.';
    } else {
        $stmt = $conn->prepare("UPDATE users SET name = ?, telephone = ? WHERE id = ?");
        $stmt->bind_param('ssi', $name, $telephone, $_SESSION['user_id']);
        if ($stmt->execute()) {
            $_SESSION['name'] = $name;
            $alertMessage = 'Profile updated successfully!';
            logAudit("Profile updated", $_SESSION['user_id']);
        } else {
            $alertMessage = 'Error updating profile.';
        }
        $stmt->close();
    }
}
?>
<?php include 'includes/header.php'; ?>
<h2>Your Profile</h2>
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email (read-only)</label>
        <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
    </div>
    <div class="mb-3">
        <label for="telephone" class="form-label">Telephone</label>
        <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo htmlspecialchars($telephone); ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Update Profile</button>
</form>
<?php if ($biodata): ?>
    <h3 class="mt-4">Bio-data</h3>
    <p><strong>Address:</strong> <?php echo htmlspecialchars($biodata['address']); ?></p>
    <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($biodata['dob']); ?></p>
    <p><strong>State of Origin:</strong> <?php echo htmlspecialchars($biodata['state_of_origin']); ?></p>
    <p><strong>Local Government:</strong> <?php echo htmlspecialchars($biodata['local_government']); ?></p>
    <p><strong>Religion:</strong> <?php echo htmlspecialchars($biodata['religion']); ?></p>
    <p><strong>Unique ID:</strong> <?php echo htmlspecialchars($biodata['unique_id']); ?></p>
    <p><strong>Eligibility Status:</strong> <?php echo htmlspecialchars($biodata['eligibility_status']); ?></p>
    <img src="<?php echo htmlspecialchars($biodata['passport_photo']); ?>" alt="Passport Photo" width="100">
<?php else: ?>
    <p>No bio-data submitted. <a href="biodata.php">Complete your bio-data</a>.</p>
<?php endif; ?>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
        });
    </script>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
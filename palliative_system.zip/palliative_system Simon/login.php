<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

$maxAttempts = 5;
$lockoutTime = 15 * 60;
if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= $maxAttempts) {
    if (time() - $_SESSION['lockout_time'] < $lockoutTime) {
        $alertMessage = 'Too many login attempts. Please try again later.';
    } else {
        unset($_SESSION['login_attempts'], $_SESSION['lockout_time']);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    if (!validateEmail($email)) {
        $alertMessage = 'Invalid email address.';
    } else {
        $stmt = $conn->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($userId, $name, $passwordHash, $role);
        if ($stmt->fetch() && password_verify($password, $passwordHash)) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['name'] = $name;
            $_SESSION['role'] = $role;
            unset($_SESSION['login_attempts'], $_SESSION['lockout_time']);
            logAudit("User logged in: $email", $userId);
            $alertMessage = 'Login successful! Redirecting to dashboard...';
            $alertActionUrl = 'dashboard.php';
            $alertActionText = 'Go to Dashboard';
        } else {
            $_SESSION['login_attempts'] = ($_SESSION['login_attempts'] ?? 0) + 1;
            if ($_SESSION['login_attempts'] >= $maxAttempts) {
                $_SESSION['lockout_time'] = time();
                $alertMessage = 'Too many login attempts. Please try again later.';
            } else {
                $alertMessage = 'Invalid credentials.';
            }
            logAudit("Failed login attempt: $email");
        }
        $stmt->close();
    }
}
?>
<?php include 'includes/header.php'; ?>



<section class="section">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-6">
                <div class="section-title text-center">
                    <h1>login</h1>
                </div>
            </div>
            <div class="col-lg-10">
                <div class="shadow rounded p-5 bg-white">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="contact-form">
                                <form method="post">
                                    <div class="form-group mb-4 pb-2">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                        <label for="email" class="form-label">Email address</label>
                                        <input type="email" class="form-control shadow-none" id="email" name="email" required>
                                    </div>
                                    <div class="form-group mb-4 pb-2">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control shadow-none" id="password" name="password" required>
                                    </div>

                                    <button class="btn btn-primary w-100" type="submit">Login</button>
                                    <a href="forgot_password.php" class="btn-link">Forgot Password?</a>

                                </form>
                                <?php if ($alertMessage): ?>
                                    <script>
                                        document.addEventListener('DOMContentLoaded', function() {
                                            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
                                        });
                                    </script>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="section-sm bg-tertiary">
	<div class="container">
		
		<div class="row align-items-center text-center text-md-start">
			<div class="col-lg-4">
        <a href="index.php">
          <img loading="prelaod" decoding="async" class="img-fluid" width="160" src="theme/images/22222222.png" alt="Wallet">
        </a>
			</div>
			<div class="col-lg-4 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4"><a class="text-black" href="privacy-policy.html">Privacy Policy</a>
					</li>
					<li class="list-inline-item me-4"><a class="text-black" href="terms.html">Terms &amp; Conditions</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-4 col-md-6 text-md-end mt-4 mt-md-0">
				<ul class="list-unstyled list-inline mb-0 social-icons">
					<li class="list-inline-item me-3"><a title="Explorer Facebook Profile" class="text-black" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Twitter Profile" class="text-black" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Instagram Profile" class="text-black" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</footer> 



<?php
require_once 'includes/functions.php';
?>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>    <script>
        // Check if bootstrap is defined before using it
        if (typeof bootstrap === 'undefined') {
            console.error('Bootstrap JavaScript is not loaded. Please check if assets/js/bootstrap.bundle.min.js is accessible.');
        }

        function showAlertModal(message, actionUrl = null, actionText = 'Close') {
            if (typeof bootstrap === 'undefined') {
                console.error('Cannot show modal: Bootstrap is not defined.');
                alert(message); // Fallback to native alert
                if (actionUrl) {
                    window.location.href = actionUrl;
                }
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('alertModal'), { backdrop: 'static' });
            const modalBody = document.getElementById('alertModalBody');
            const closeBtn = document.getElementById('alertModalClose');
            const actionBtn = document.getElementById('alertModalAction');

            modalBody.innerText = message;
            if (actionUrl) {
                actionBtn.classList.remove('d-none');
                actionBtn.innerText = actionText;
                actionBtn.onclick = function() {
                    window.location.href = actionUrl;
                };
            } else {
                actionBtn.classList.add('d-none');
            }

            closeBtn.onclick = function() {
                modal.hide();
            };

            modal.show();
            console.log('Modal shown with message:', message, 'Action URL:', actionUrl);
        }
    </script>
</body>
</html>
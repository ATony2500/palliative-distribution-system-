<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$alertMessage = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $token = sanitizeInput($_POST['token']);
    $password = $_POST['password'];
    if (!validatePassword($password)) {
        $alertMessage = 'Password must be at least 8 characters, with uppercase, lowercase, number, and special character.';
    } else {
        $stmt = $conn->prepare("SELECT email FROM password_resets WHERE token = ? AND expires_at > NOW()");
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $stmt->bind_result($email);
        if ($stmt->fetch()) {
            $stmt->close();
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->bind_param('ss', $passwordHash, $email);
            if ($stmt->execute()) {
                $stmt->close();
                $stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
                $stmt->bind_param('s', $token);
                $stmt->execute();
                $alertMessage = 'Password reset successful! Please login.';
                $alertActionUrl = 'login.php';
                $alertActionText = 'Login';
            }
        } else {
            $alertMessage = 'Invalid or expired token.';
        }
        $stmt->close();
    }
}
$token = isset($_GET['token']) ? sanitizeInput($_GET['token']) : '';
?>
<?php include 'includes/header.php'; ?>
<h2>Reset Password</h2>
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
    <div class="mb-3">
        <label for="password" class="form-label">New Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary">Reset Password</button>
</form>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
        });
    </script>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
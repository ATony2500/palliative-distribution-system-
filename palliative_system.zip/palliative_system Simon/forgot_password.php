<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$alertMessage = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $email = sanitizeInput($_POST['email']);
    if (!validateEmail($email)) {
        $alertMessage = 'Invalid email address.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($userId);
        if ($stmt->fetch()) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
            $stmt->bind_param('sss', $email, $token, $expires);
            if ($stmt->execute()) {
                $alertMessage = 'Password reset instructions would be sent to your email if email functionality was enabled.';
            }
        } else {
            $alertMessage = 'Email not found.';
        }
        $stmt->close();
    }
}
?>
<?php include 'includes/header.php'; ?>
<h2>Forgot Password</h2>
<form method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
    <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
    </div>
    <button type="submit" class="btn btn-primary">Send Reset Link</button>
</form>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>');
        });
    </script>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
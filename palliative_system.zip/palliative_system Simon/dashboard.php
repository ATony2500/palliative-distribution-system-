<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

// Fetch delivery details
$stmt = $conn->prepare("SELECT d.status, d.scheduled_date, d.tracking_number, d.address 
                        FROM deliveries d 
                        WHERE d.user_id = ? 
                        ORDER BY d.created_at DESC 
                        LIMIT 1");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$delivery = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch bio-data for PDF download
$stmt = $conn->prepare("SELECT unique_id FROM user_biodata WHERE user_id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$biodata = $stmt->get_result()->fetch_assoc();
$stmt->close();
?>
<?php include 'includes/header.php'; ?>
<h2>Welcome, <?php echo htmlspecialchars($_SESSION['name'] ?? 'User'); ?></h2>
<div class="row">
    <div class="col-md-6">
        <h3>Your Actions</h3>
        <a href="biodata.php" class="btn btn-primary mb-2">View/Edit Bio-data</a>
        <a href="profile.php" class="btn btn-secondary mb-2">View Profile</a>
        <?php if ($biodata && isset($biodata['unique_id'])): ?>
            <a href="generate_pdf.php?unique_id=<?php echo htmlspecialchars($biodata['unique_id']); ?>" class="btn btn-info mb-2">Download PDF</a>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <h3>Delivery Status</h3>
        <?php if ($delivery): ?>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($delivery['status']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($delivery['address']); ?></p>
            <p><strong>Scheduled Date:</strong> <?php echo htmlspecialchars($delivery['scheduled_date'] ?? 'Not scheduled'); ?></p>
            <p><strong>Tracking Number:</strong> <?php echo htmlspecialchars($delivery['tracking_number'] ?? 'N/A'); ?></p>
        <?php else: ?>
            <p>No delivery scheduled. Submit your bio-data and await approval.</p>
        <?php endif; ?>
    </div>
</div>
<!-- Bootstrap Modal -->
<div class="modal fade" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="alertModalLabel">Alert</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="alertModalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="alertModalClose" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary d-none" id="alertModalAction">Confirm</button>
            </div>
        </div>
    </div>
</div>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
        });
    </script>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
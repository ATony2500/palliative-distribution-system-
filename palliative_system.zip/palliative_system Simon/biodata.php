<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $address = sanitizeInput($_POST['address']);
    $dob = $_POST['dob'];
    $state_of_origin = sanitizeInput($_POST['state_of_origin']);
    $local_government = sanitizeInput($_POST['local_government']);
    $religion = sanitizeInput($_POST['religion']);
    $unique_id = 'PAL' . rand(10000, 99999);
    $target_dir = "assets/uploads/";
    
    $fileValidation = validateFile($_FILES['passport_photo']);
    if (!$fileValidation['valid']) {
        $alertMessage = $fileValidation['error'];
    } else {
        $ext = pathinfo($_FILES['passport_photo']['name'], PATHINFO_EXTENSION);
        $filename = $unique_id . '.' . $ext;
        $passport_photo = $target_dir . $filename;
        if (move_uploaded_file($_FILES['passport_photo']['tmp_name'], $passport_photo)) {
            $stmt = $conn->prepare("INSERT INTO user_biodata (user_id, address, dob, state_of_origin, local_government, religion, passport_photo, unique_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('isssssss', $_SESSION['user_id'], $address, $dob, $state_of_origin, $local_government, $religion, $passport_photo, $unique_id);
            if ($stmt->execute()) {
                logAudit("Bio-data submitted: $unique_id", $_SESSION['user_id']);
                $stmt->close();
                $stmt = $conn->prepare("SELECT email FROM users WHERE id = ?");
                $stmt->bind_param('i', $_SESSION['user_id']);
                $stmt->execute();
                $stmt->bind_result($email);
                $stmt->fetch();
                if (!sendEmail($email, "Bio-data Submission", "Your bio-data has been submitted. Unique ID: $unique_id")) {
                    $alertMessage = "Bio-data submitted successfully, Your Unique ID: $unique_id";
                } else {
                    $alertMessage = "Bio-data submitted successfully! Your Unique ID: $unique_id";
                }
                $alertActionUrl = "generate_pdf.php?unique_id=$unique_id";
                $alertActionText = 'Download PDF';
            } else {
                logError("Bio-data submission failed: " . $conn->error);
                $alertMessage = 'Error submitting bio-data.';
            }
            $stmt->close();
        } else {
            $alertMessage = 'Error uploading file.';
        }
    }
}
?>
<?php include 'includes/header.php'; ?>
<h2>Bio-data Form</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
    <div class="mb-3">
        <label for="address" class="form-label">Address</label>
        <textarea class="form-control" id="address" name="address" required></textarea>
    </div>
    <div class="mb-3">
        <label for="dob" class="form-label">Date of Birth</label>
        <input type="date" class="form-control" id="dob" name="dob" required>
    </div>
    <div class="mb-3">
        <label for="state_of_origin" class="form-label">State of Origin</label>
        <input type="text" class="form-control" id="state_of_origin" name="state_of_origin" required>
    </div>
    <div class="mb-3">
        <label for="local_government" class="form-label">Local Government</label>
        <input type="text" class="form-control" id="local_government" name="local_government" required>
    </div>
    <div class="mb-3">
        <label for="religion" class="form-label">Religion</label>
        <input type="text" class="form-control" id="religion" name="religion" required>
    </div>
    <div class="mb-3">
        <label for="passport_photo" class="form-label">Passport Photo (JPEG/PNG, max 2MB)</label>
        <input type="file" class="form-control" id="passport_photo" name="passport_photo" accept="image/jpeg,image/png" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php if ($alertMessage): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
        });
    </script>
<?php endif; ?>
<?php include 'includes/footer.php'; ?>
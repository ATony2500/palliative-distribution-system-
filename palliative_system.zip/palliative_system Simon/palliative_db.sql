-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 10, 2025 at 01:39 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `palliative_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
CREATE TABLE IF NOT EXISTS `deliveries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `biodata_id` int NOT NULL,
  `address` text NOT NULL,
  `status` enum('pending','scheduled','in_transit','delivered') DEFAULT 'pending',
  `scheduled_date` date DEFAULT NULL,
  `tracking_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `biodata_id` (`biodata_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`id`, `user_id`, `biodata_id`, `address`, `status`, `scheduled_date`, `tracking_number`, `created_at`, `updated_at`) VALUES
(1, 12, 5, '20 Abuja Ave Lafia', 'delivered', '2025-07-28', 'ABCDE123', '2025-07-28 14:31:09', '2025-07-28 14:42:49'),
(2, 13, 6, 'jericho street Lafia', 'delivered', '2025-07-28', 'ACBDE1233', '2025-07-28 14:39:04', '2025-07-30 01:49:25'),
(3, 14, 7, '88 Love angle Ave Lafia', 'delivered', '2025-07-28', 'ABCDE12339', '2025-07-28 14:46:35', '2025-07-30 01:49:47'),
(4, 15, 8, '19 Baker&#039;s street Maitama Abuja', 'scheduled', '2025-07-30', 'ABCDE1233', '2025-07-28 14:47:22', '2025-07-30 04:50:41'),
(5, 2, 9, 'haven', 'pending', NULL, NULL, '2025-07-28 14:48:21', '2025-07-30 03:41:33'),
(6, 17, 11, '88 blake ave abuja', 'delivered', '2025-07-30', 'ABCDE123390', '2025-07-30 01:38:08', '2025-07-30 01:40:19'),
(7, 17, 11, '88 blake ave abuja', 'scheduled', '2025-07-30', 'ABCD2221', '2025-07-30 01:38:10', '2025-07-30 01:48:35'),
(8, 16, 10, '10 Nazareth street Lafia', 'pending', NULL, NULL, '2025-07-30 01:44:10', '2025-07-30 01:44:10'),
(9, 2, 15, 'space', 'pending', NULL, NULL, '2025-07-30 04:55:21', '2025-07-30 04:55:21'),
(10, 2, 14, 'new yok', 'pending', NULL, NULL, '2025-07-30 04:57:31', '2025-07-30 04:57:31');

-- --------------------------------------------------------

--
-- Table structure for table `disbursements`
--

DROP TABLE IF EXISTS `disbursements`;
CREATE TABLE IF NOT EXISTS `disbursements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `disbursement_details` text NOT NULL,
  `disbursement_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `disbursements`
--

INSERT INTO `disbursements` (`id`, `user_id`, `disbursement_details`, `disbursement_date`) VALUES
(1, 2, 'Granted', '2025-07-28 10:57:22'),
(2, 11, 'okpa #100', '2025-07-28 12:21:06'),
(3, 10, 'clay', '2025-07-28 12:30:56'),
(4, 10, 'loop', '2025-07-28 13:15:14'),
(5, 12, 'k', '2025-07-28 14:39:52'),
(6, 17, 'new car', '2025-07-30 01:39:44'),
(7, 16, 'new car', '2025-07-30 01:47:08');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `telephone`, `email`, `password`, `role`, `created_at`) VALUES
(4, 'Admin User', '1234567890', 'admin@example.com', '$2y$10$6rSwuKA4FwCTqoU8GwMy1e5l1Y40g8j9OCZXeY1qsyOxBfnZBWTO2', 'admin', '2025-07-25 00:53:27'),
(2, 'Tony', '08152167257', 'tony@gmail.com', '$2y$10$vRCe9o10dxo8RB6uu/JMmOnjDMR9uJIR6tgbPDtA.FjslQhWW6V8m', 'admin', '2025-07-24 23:57:22'),
(3, 'newadmin', '', 'newadmin@gmail.com', 'YourPassword123!', 'admin', '2025-07-25 00:18:00'),
(5, 'Simon', '08152167257', 'simon@gmail.com', '$2y$10$qU2ENdBM0XUvJsbHzXmkA.TsXnCvuj.Q9KP6VXfpcl8zHiBjjD/6q', 'admin', '2025-07-25 01:38:53'),
(6, 'Aboje Simon', '08187514141', 'abojesimon45@gmail.com', '$2y$10$RyvMmsOw9tqQ54XKlwgXueQgriw0snLbuF.V4sRqo3Kuh5ZuEOySS', 'admin', '2025-07-25 02:43:59'),
(7, 'James Maddison', '08187514141', 'james245@gmail.com', '$2y$10$B.HeGyVPKOQmOYuxemiQTec3fCyrEKpsPYc2ASlKprZRQ/L5V7xw2', 'user', '2025-07-25 10:48:46'),
(8, 'jerry jones', '08152167257', 'jerryjones@gmail.com', '$2y$10$35TMoAO5wkHeJwe6Ep96UOoyTnautVtCDsquR9L4vqn2GfLmm4awS', 'user', '2025-07-25 10:50:38'),
(9, 'jerry jones', '08152167257', 'je@gmail.com', '$2y$10$gnYcNLMYPDXobhJv48hQ1.ea8ekt9osyxoQgWXLrCkdaYQsUxL0Fa', 'user', '2025-07-25 10:52:44'),
(10, 'Adaobi Lydia', '08152167257', 'next@gmail.com', '$2y$10$esUrxIe/uF8UnbsNxuugku9twh49HmOrqlRGWBDDQcC0DEVsEtyt6', 'user', '2025-07-28 11:08:51'),
(11, 'Solomon grundy', '08187514141', 'next22@gmail.com', '$2y$10$S6qSCbGbleIS6K0CU4QpVuHK8t/BANgKHTmI2LEa1GvEz5obuYPba', 'user', '2025-07-28 11:12:20'),
(12, 'Monica James', '08187514141', 'next33@gmail.com', '$2y$10$6dASLMxAM/MrzxoRr1OVk.2yWGoyYe2QnXpevqICw9w17acNvOCGS', 'user', '2025-07-28 11:19:23'),
(13, 'Joy Ifeoma', '08187514141', 'next44@gmail.com', '$2y$10$47AUMmu6h7uOoVwlaVXhnOzyyvnKfBcAEQRTpuk.dj8r.2b7s1GvW', 'user', '2025-07-28 11:25:08'),
(14, 'Amos  Grant', '08187514141', 'next55@gmail.com', '$2y$10$9UPYdYFXnyNM31tKr46umeIpy.iL7iYpX9QHuveN0IhFH1toYjn8q', 'user', '2025-07-28 11:30:17'),
(15, 'Billy Jean', '08187514141', 'next66@gmail.com', '$2y$10$yBS2xc/SPYxcXgk0LwJhpuplPrdLBh0XMFp9NAPdYSIiOwr6Vitk.', 'user', '2025-07-28 11:35:00'),
(16, 'Solomon Moses', '08187514141', 'next77@gmail.com', '$2y$10$ZxeK/h4lLQ/9.CzQxFzpTuHBUaVCME11YQ1nwCr7X2f14cbv7fhOS', 'user', '2025-07-29 23:05:50'),
(17, 'Simon Giggs', '08187514141', 'next88@gmail.com', '$2y$10$seMR33mbeD4cG/e3.wjp6e2AZIkJZXmJECLhoLuHkAwOKvQRcztdK', 'user', '2025-07-29 23:10:40'),
(18, 'Moses Klint', '08187514141', 'next99@gmail.com', '$2y$10$cyPs8a629gdom47DvpOIS.f7GB0D/ohEyW3XEl2e3/LhkcUGsOKvS', 'user', '2025-07-29 23:16:31'),
(19, 'James Graham', '08187514141', 'next00@gmail.com', '$2y$10$yeHjeSM6TvQm4i6wbS8J1u5NMBzZiSg3/vw1vnZBRPkz8JoxP01Pe', 'user', '2025-07-29 23:23:53'),
(20, 'Simon Black', '08187514141', 'next001@gmail.com', '$2y$10$1/huGG9uSwFrUeu4oTsOfeEMUSgK8hnpha.hBIhJokoPE8AWtWNoO', 'admin', '2025-07-30 01:54:55'),
(21, 'Anthony Oloyede', '0815216725', 'next002@gmail.com', '$2y$10$PdtcPTWzH/N526o3rXnw7efE4uIytHNDgm5D5Jj.5CZvYwwi.15Km', 'user', '2025-07-30 09:16:24'),
(22, 'Moses Oche', '08187514141', 'next003@gmail.com', '$2y$10$az4rmHrIE00U7JSTvTwuUewvpx3Cgm/62N1k2KBxft8/JImNlxXUe', 'user', '2025-07-30 09:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `user_biodata`
--

DROP TABLE IF EXISTS `user_biodata`;
CREATE TABLE IF NOT EXISTS `user_biodata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `address` text NOT NULL,
  `dob` date NOT NULL,
  `passport_photo` varchar(255) NOT NULL,
  `unique_id` varchar(20) NOT NULL,
  `eligibility_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `state_of_origin` varchar(100) NOT NULL,
  `local_government` varchar(100) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_id` (`unique_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_biodata`
--

INSERT INTO `user_biodata` (`id`, `user_id`, `address`, `dob`, `passport_photo`, `unique_id`, `eligibility_status`, `state_of_origin`, `local_government`, `religion`, `created_at`) VALUES
(1, 1, 'Abuja', '2005-07-13', 'assets/uploads/PAL71624.jpg', 'PAL71624', 'approved', 'Benue', 'Ohimini', 'Muslim', '2025-07-19 00:28:41'),
(2, 2, 'no 10 akunza lafia', '1996-08-03', 'assets/uploads/PAL89818.jpg', 'PAL89818', 'approved', '', '', '', '2025-07-28 03:00:26'),
(10, 16, '10 Nazareth street Lafia', '1997-10-11', 'assets/uploads/PAL18384.jpg', 'PAL18384', 'approved', '', '', '', '2025-07-29 23:08:33'),
(14, 2, 'new yok', '2025-07-30', 'assets/uploads/PAL23036.jpg', 'PAL23036', 'approved', '', '', '', '2025-07-30 03:49:45'),
(18, 21, '12 Mararaba Akunza Lafia', '1992-08-08', 'assets/uploads/PAL38953.jpg', 'PAL38953', 'pending', 'Lagos', 'Oshodi', 'Christian', '2025-07-30 09:19:01'),
(6, 13, 'jericho street Lafia', '1996-10-22', 'assets/uploads/PAL12155.jpg', 'PAL12155', 'approved', '', '', '', '2025-07-28 11:27:53'),
(8, 15, '19 Baker&#039;s street Maitama Abuja', '1992-08-11', 'assets/uploads/PAL39895.jpg', 'PAL39895', 'approved', '', '', '', '2025-07-28 11:37:30'),
(9, 2, 'haven', '2004-02-03', 'assets/uploads/PAL35834.jpg', 'PAL35834', 'approved', '', '', '', '2025-07-28 13:49:09'),
(11, 17, '88 blake ave abuja', '1999-02-02', 'assets/uploads/PAL17512.jpg', 'PAL17512', 'approved', '', '', '', '2025-07-29 23:13:52'),
(12, 18, '10  blake ave', '1998-06-16', 'assets/uploads/PAL69182.jpg', 'PAL69182', 'approved', '', '', '', '2025-07-29 23:20:22'),
(13, 19, 'Mak ave lafia', '1992-10-16', 'assets/uploads/PAL68602.jpg', 'PAL68602', 'approved', '', '', '', '2025-07-29 23:26:27'),
(15, 2, 'space', '2025-07-30', 'assets/uploads/PAL33083.jpg', 'PAL33083', 'approved', 'kaduna', 'Ohimini', 'Christian', '2025-07-30 04:07:53'),
(16, 2, 'space', '2025-07-30', 'assets/uploads/PAL81151.jpg', 'PAL81151', 'pending', 'Lagos', 'Ikeja', 'Christian', '2025-07-30 04:24:08'),
(17, 2, 'space', '2025-07-30', 'assets/uploads/PAL69174.jpg', 'PAL69174', 'pending', 'Lagos', 'Ikeja', 'Christian', '2025-07-30 04:26:17');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

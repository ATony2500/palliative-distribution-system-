<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
logAudit("User logged out", $_SESSION['user_id'] ?? null);
session_destroy();
header('Location: login.php');
exit;
?>
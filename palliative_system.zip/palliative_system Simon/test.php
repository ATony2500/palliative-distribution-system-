<?php
require 'includes/config.php';
echo "<pre>";
print_r($_ENV);
echo "</pre>";
?>
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$alertMessage = '';
$alertActionUrl = '';
$alertActionText = 'Close';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && validateCsrfToken($_POST['csrf_token'])) {
    $name = sanitizeInput($_POST['name']);
    $telephone = sanitizeInput($_POST['telephone']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    if (!validateEmail($email)) {
        $alertMessage = 'Invalid email address.';
    } elseif (!validatePhone($telephone)) {
        $alertMessage = 'Invalid phone number.';
    } elseif (!validatePassword($password)) {
        $alertMessage = 'Password must be at least 8 characters, with uppercase, lowercase, number, and special character.';
    } else {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();

        if ($count > 0) {
            $alertMessage = 'Email already registered.';
        } else {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $role = 'user';
            $stmt = $conn->prepare("INSERT INTO users (name, telephone, email, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('sssss', $name, $telephone, $email, $passwordHash, $role);
            if ($stmt->execute()) {
                logAudit("User registered: $email", $stmt->insert_id);
                $alertMessage = 'Registration successful! Please login.';
                $alertActionUrl = 'login.php';
                $alertActionText = 'Login';
            } else {
                logError("Registration failed: " . $conn->error);
                $alertMessage = 'Registration failed. Please try again.';
            }
            $stmt->close();
        }
    }
}
?>
<?php include 'includes/header.php'; ?>

<section class="section">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-6">
                <div class="section-title text-center">
                    <h1>register</h1>
                </div>
            </div>
            <div class="col-lg-10">
                <div class="shadow rounded p-5 bg-white">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="contact-form">
                                <form method="POST" id="registerForm">
                                <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                                    <div class="form-group mb-4 pb-2">
                                        <label for="name" class="form-label">Name</label>
                                        <input type="text" class="form-control" id="name" name="name" required>
                                    </div>
                                    <!-- <div class="form-group mb-3 pb-2">
                                    </div> -->
                                    <div class="form-group mb-3 pb-2">
                                        <label for="telephone" class="form-label">Telephone</label>
                                        <input type="text" class="form-control" id="telephone" name="telephone" required>
                                    </div>
                                    <!-- <div class="mb-3"><div class="mb-3">
                                        <label for="telephone" class="form-label">Telephone</label>
                                        <input type="text" class="form-control" id="telephone" name="telephone" required>
                                    </div> -->
                                    <!-- <div class="form-group mb-3 pb-2"></div>     -->
                                    <div class="form-group mb-4 pb-2">
                                            <label for="email" class="form-label">Email address</label>
                                        <input type="email" class="form-control shadow-none" id="email" name="email" required>
                                    </div>
                                    <div class="form-group mb-4 pb-2">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control shadow-none" id="password" name="password" required>
                                    </div>

                                    <button class="btn btn-primary w-100" type="submit">Register</button>
                                    <a href="forgot_password.php" class="btn-link">Forgot Password?</a>

                                </form>
                                <?php if ($alertMessage): ?>
                                    <script>
                                        document.addEventListener('DOMContentLoaded', function() {
                                            showAlertModal('<?php echo htmlspecialchars($alertMessage); ?>', '<?php echo $alertActionUrl; ?>', '<?php echo $alertActionText; ?>');
                                        });
                                    </script>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="section-sm bg-tertiary">
	<div class="container">
		
		<div class="row align-items-center text-center text-md-start">
			<div class="col-lg-4">
        <a href="index.php">
          <img loading="prelaod" decoding="async" class="img-fluid" width="160" src="theme/images/22222222.png" alt="Wallet">
        </a>
			</div>
			<div class="col-lg-4 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center">
					<li class="list-inline-item me-4"><a class="text-black" href="privacy-policy.html">Privacy Policy</a>
					</li>
					<li class="list-inline-item me-4"><a class="text-black" href="terms.html">Terms &amp; Conditions</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-4 col-md-6 text-md-end mt-4 mt-md-0">
				<ul class="list-unstyled list-inline mb-0 social-icons">
					<li class="list-inline-item me-3"><a title="Explorer Facebook Profile" class="text-black" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Twitter Profile" class="text-black" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Instagram Profile" class="text-black" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</footer> 

<?php include 'includes/footer.php'; ?>


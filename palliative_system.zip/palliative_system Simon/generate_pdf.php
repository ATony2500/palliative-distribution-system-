<?php
require_once 'vendor/autoload.php';
require_once 'includes/db.php';
require_once 'includes/functions.php';

use Dompdf\Dompdf;

if (!isset($_GET['unique_id'])) {
    die("Invalid request");
}
$unique_id = sanitizeInput($_GET['unique_id']);
$stmt = $conn->prepare("SELECT u.name, u.email, u.telephone, b.address, b.dob, b.state_of_origin, b.local_government, b.religion, b.passport_photo, b.unique_id, b.eligibility_status, d.status AS delivery_status, d.scheduled_date, d.tracking_number 
                        FROM users u 
                        JOIN user_biodata b ON u.id = b.user_id 
                        LEFT JOIN deliveries d ON b.id = d.biodata_id 
                        WHERE b.unique_id = ?");
$stmt->bind_param('s', $unique_id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$data) {
    die("Beneficiary not found");
}

// Check if passport photo exists and is readable
$passport_photo = $data['passport_photo'] ?? '';
$image_html = '';
if (!empty($passport_photo) && file_exists($passport_photo) && is_readable($passport_photo)) {
    $image_html = '<img src="' . htmlspecialchars($passport_photo) . '" alt="Passport Photo" style="width: 100px; height: 100px; object-fit: cover; margin-bottom: 10px;">';
} else {
    $image_html = '<p style="color: red;">Passport photo not available</p>';
    logError("Passport photo not found or unreadable for unique_id: $unique_id, path: $passport_photo");
}

$dompdf = new Dompdf();
$html = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12pt; }
        h1 { font-size: 18pt; margin-bottom: 10px; }
        h3 { font-size: 14pt; margin-top: 20px; }
        p { margin: 5px 0; }
        img { display: block; }
    </style>
</head>
<body>
    <h1>Palliative Beneficiary Details</h1>
    ' . $image_html . '
    <p><strong>Name:</strong> ' . htmlspecialchars($data['name']) . '</p>
    <p><strong>Email:</strong> ' . htmlspecialchars($data['email']) . '</p>
    <p><strong>Telephone:</strong> ' . htmlspecialchars($data['telephone']) . '</p>
    <p><strong>Address:</strong> ' . htmlspecialchars($data['address']) . '</p>
    <p><strong>Date of Birth:</strong> ' . htmlspecialchars($data['dob']) . '</p>
    <p><strong>State of Origin:</strong> ' . htmlspecialchars($data['state_of_origin']) . '</p>
    <p><strong>Local Government:</strong> ' . htmlspecialchars($data['local_government']) . '</p>
    <p><strong>Religion:</strong> ' . htmlspecialchars($data['religion']) . '</p>
    <p><strong>Unique ID:</strong> ' . htmlspecialchars($data['unique_id']) . '</p>
    <p><strong>Eligibility Status:</strong> ' . htmlspecialchars($data['eligibility_status']) . '</p>
    <h3>Delivery Details</h3>
    <p><strong>Status:</strong> ' . htmlspecialchars($data['delivery_status'] ?? 'Not scheduled') . '</p>
    <p><strong>Scheduled Date:</strong> ' . htmlspecialchars($data['scheduled_date'] ?? 'N/A') . '</p>
    <p><strong>Tracking Number:</strong> ' . htmlspecialchars($data['tracking_number'] ?? 'N/A') . '</p>
</body>
</html>
';
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('beneficiary_details_' . $unique_id . '.pdf', ['Attachment' => 1]);
logAudit("PDF generated for unique ID: $unique_id", $_SESSION['user_id'] ?? null);
?>
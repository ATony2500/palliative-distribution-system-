<?php
// require '../vendor/autoload.php';
// use Dotenv\Dotenv;

// try {
//     $dotenv = Dotenv::createImmutable(__DIR__ . '/..');
//     $dotenv->load();
//     // Verify required environment variables
//     $required = ['DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME', 'EMAIL_HOST', 'EMAIL_USER', 'EMAIL_PASS', 'EMAIL_FROM', 'RECAPTCHA_SECRET'];
//     $dotenv->required($required)->notEmpty();
// } catch (Exception $e) {
//     error_log("Failed to load .env file: " . $e->getMessage());
//     die("Configuration error. Please contact the administrator.");
// }


require __DIR__ . '/../vendor/autoload.php';
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

?>

<?php
require_once 'includes/functions.php';
?>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>    <script>
        // Check if bootstrap is defined before using it
        if (typeof bootstrap === 'undefined') {
            console.error('Bootstrap JavaScript is not loaded. Please check if assets/js/bootstrap.bundle.min.js is accessible.');
        }

        function showAlertModal(message, actionUrl = null, actionText = 'Close') {
            if (typeof bootstrap === 'undefined') {
                console.error('Cannot show modal: Bootstrap is not defined.');
                alert(message); // Fallback to native alert
                if (actionUrl) {
                    window.location.href = actionUrl;
                }
                return;
            }

            const modal = new bootstrap.Modal(document.getElementById('alertModal'), { backdrop: 'static' });
            const modalBody = document.getElementById('alertModalBody');
            const closeBtn = document.getElementById('alertModalClose');
            const actionBtn = document.getElementById('alertModalAction');

            modalBody.innerText = message;
            if (actionUrl) {
                actionBtn.classList.remove('d-none');
                actionBtn.innerText = actionText;
                actionBtn.onclick = function() {
                    window.location.href = actionUrl;
                };
            } else {
                actionBtn.classList.add('d-none');
            }

            closeBtn.onclick = function() {
                modal.hide();
            };

            modal.show();
            console.log('Modal shown with message:', message, 'Action URL:', actionUrl);
        }
    </script>
</body>
</html>